<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Image;
use App\Record;
use App\ImageInformation;

class EncryptorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function index()
    {
        //
    }

    public function indexUpload() {
        $data['records'] = Record::orderBy('created_at','DESC')->where('status','=',0)->get();
        return view('dashboard.encrypted_list')->with($data);
    }

    public function decryptList() {
        $data['records'] = Record::orderBy('created_at','DESC')->where('status','=',1)->get();
        return view('dashboard.decrypted_list')->with($data);
    }


    public function viewImage($id) {
        $data['record'] = Record::find($id);
        $meta = ImageInformation::where('record_id','=',$id)->get();
        $metadata = [];
        foreach($meta as $m) {
            $metadata = $m;
        }

        $data['metadata'] = $metadata;

        return view('dashboard.view_image')->with($data);
    }

    public function viewDecryptImage($id) {
        $data['record'] = Record::find($id);

        return view('dashboard.view_decrypt_image')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    function getColorValues($img) {
        $x = $img->width();
        $y = $img->height();
        $rgb[][] = Array();
        for ($i=0; $i<$x; $i++) {
            for ($j=0; $j<$y; $j++) {
                $rgb[$i][$j] = $img->pickColor($i, $j);
            }
        }
        
        return $rgb;
    }

    function valueTransformation($pixel) {
        $colors = $img->pixel($rgb, rand($i,20), rand($j,20));
        return true;
    }


    public function scrambleImage(Request $request)
    {
        $data = $request->except('_token');

        if($request->hasFile('upload_image')) {
            try {
                //overriding PHP's default execution time limit
                ini_set('max_execution_time',0);
                ini_set('memory_limit', '-1');
                $time_start = microtime(true);

                $img = Image::make($request->file('upload_image'));

                $passes = 2;

                //scrambling the image
                $scramble = $this->scramble($img,$passes);

                $time_end = microtime(true);
                $execution_time = ($time_end - $time_start)/60;

                //storing the information
                $upload = new Record();
                $upload->slug = "/path";
                $upload->metadata = "null";
                $upload->save();

                $file_ext = $request->file('upload_image')->getClientOriginalExtension();
                $path = public_path("/img/scrambled/$upload->id.png");

                $update = Record::find($upload->id);
                $update->slug = $path;
                $update->save();

                $metadata = Image::make($request->file('upload_image'))->exif();
                $meta = (array)$metadata;
                // dd($meta);
                $image_info = new ImageInformation();

                if(isset($metadata)) {
                    foreach($metadata as $key => $d) {
                        if($key === 'FileSize') {
                            $image_info->size = $d;
                        }
    
                        if($key === 'FileDateTime') {
                            $image_info->file_date_time = $d;
                        }
                        
                        if($key === 'FileType') {
                            $image_info->file_type = $d;
                        }
    
                        if($key === 'MimeType') {
                            $image_info->mime_type = $d;
                        }
    
                        if($key === 'Model') {
                            $image_info->image_model = $d;
                        }
    
                        if($key === 'Orientation') {
                            $image_info->orientation = $d;
                        }
    
                        if($key === 'LightSource') {
                            $image_info->light_source = $d;
                        }
    
                        if($key === 'Flash') {
                            $image_info->flash = $d;
                        }
    
                        if($key === 'FocalLength') {
                            $image_info->local_length = $d;
                        }
                       
                        if($key === 'COMPUTED') {
                            foreach($d as $k => $c) {
                                if($k === 'Height') {
                                    $image_info->height = $c;
                                }
    
                                if($k === 'Width') {
                                    $image_info->width = $c;
                                }
                            }
                        }
    
                        $image_info->record_id = $upload->id;
                    }
    
                    $image_info->save();
                }

                //storing the encrypted image
                $image = $scramble->save($path);
                $time = round($execution_time);

                return $response = [
                    'msg' => "Image encrypted and saved successfully in $time Minutes",
                    'type' => "true"
                ];

            } catch(Exception $e) {
                return $response = [
                    'msg' => "Internal Server Error",
                    'type' => "false"
                ];
            }
        } else {
            return $response = [
                'msg' => "No file found",
                'type' => "false"
            ];
        }
    }


    protected function scramble($img,$runs) {
        if(isset($img)) {
            
            //initializing compulsory arrays
            $pixels[][] = Array();
            $newPixels[][] = Array();
            $newImage = [];

            //iterating through the numbers of runs given
            for ($a = 0; $a < $runs; $a++) {

                //looping through the image to get RGB values of each pixel
                for ($i = 0; $i < $img->width(); $i++) {
                    for ($j=0; $j < $img->height(); $j++) {
                        $pixels[$i][$j] = $img->pickColor($i, $j);
                    }
                }
                
                //calculating the dimension of the given image
                $amount = $img->height() * $img->width();
                $list = [];

                //storing scramble format on list
                for ($b = 0; $b < $amount; $b++) {
                    $list[$b] = $b;
                }
                
                //transposing each pixel using Knight Chess Movement
                $mapping = [];
                for($i = $amount - 1; $i >= 0; $i--) {
                    $num = (abs((int)(sin($i) * $amount ))) % ($i + 1);
                    $mapping[$i] = $list[$num];
                    $list[$num] = $list[$i];
                }
                
                //transposing the color values using RNS
                for($xz = 0; $xz < $amount; $xz++) {
                    $x = $xz % $img->width();
                    $z = $xz / $img->width();
                    $xzMap = $mapping[$xz];
                    $newX = $xzMap % $img->width();
                    $newZ = $xz / $img->width();
                    
                    //determining wheather to reverse the whole process
                    $newPixels[$x][$z] = $pixels[$newX][$newZ];
                }
                
                //generating the scrambled image
                for ($i = 0; $i < $img->width(); $i++) {
                    for ($j=0; $j < $img->height(); $j++) {
                        $newImage = @$img->pixel($newPixels[$i][$j], $i, $j);
                    }
                }
            }

            return $newImage;
        }
    }


    protected function unscramble($img,$runs) {
        if(isset($img)) {
            
            //initializing compulsory arrays
            $pixels[][] = Array();
            $newPixels[][] = Array();
            $newImage = [];

            //iterating through the numbers of runs given
            for ($a = 0; $a < $runs; $a++) {

                //looping through the image to get RGB values of each pixel
                for ($i = 0; $i < $img->width(); $i++) {
                    for ($j=0; $j < $img->height(); $j++) {
                        $pixels[$i][$j] = $img->pickColor($i, $j);
                    }
                }
                
                //calculating the dimension of the given image
                $amount = $img->height() * $img->width();
                $list = [];

                //storing scramble format on list
                for ($b = 0; $b < $amount; $b++) {
                    $list[$b] = $b;
                }
                
                //transposing each pixel using Knight Chess Movement
                $mapping = [];
                for($i = $amount - 1; $i >= 0; $i--) {
                    $num = (abs((int)(sin($i) * $amount ))) % ($i + 1);
                    $mapping[$i] = $list[$num];
                    $list[$num] = $list[$i];
                }
                
                //transposing the color values using RNS
                for($xz = 0; $xz < $amount; $xz++) {
                    $x = $xz % $img->width();
                    $z = $xz / $img->width();
                    $xzMap = $mapping[$xz];
                    $newX = $xzMap % $img->width();
                    $newZ = $xz / $img->width();
                    
                    //determining wheather to reverse the whole process
                    $newPixels[$newX][$newZ] = $pixels[$x][$z];
                    array_values($newPixels);
                }
                
                //generating the scrambled image
                for ($i = 0; $i < $img->width(); $i++) {
                    for ($j=0; $j < $img->height(); $j++) {
                        $newImage = @$img->pixel($newPixels[$i][$j], $i, $j);
                    }
                }
            }

            return $newImage;
        }
    }

    public function unscrambleImage(Request $request)
    {
        $data = $request->except('_token');

        if($data['record_id']) {
            try {
                //overriding PHP's default execution time limit
                ini_set('max_execution_time',0);
                ini_set('memory_limit', '-1');
                $time_start = microtime(true);
                $id = $data['record_id'];

                $img = Image::make("img/scrambled/$id.png");
                $passes = 2;

                //scrambling the image
                $scramble = $this->unscramble($img,$passes);

                $time_end = microtime(true);
                $execution_time = ($time_end - $time_start)/60;

                $path = public_path("/img/unscrambled/$id.png");

                //storing the information
                $record = Record::find($id);
                $record->status = 1;
                $record->save();

                //storing the decrypted image
                $image = $scramble->save($path);
                $time = round($execution_time);

                return $response = [
                    'msg' => "Image decrypted successfully in $time Minutes",
                    'type' => "true"
                ];

            } catch(Exception $e) {
                return $response = [
                    'msg' => "Internal Server Error",
                    'type' => "false"
                ];
            }
        } else {
            return $response = [
                'msg' => "No file found",
                'type' => "false"
            ];
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
