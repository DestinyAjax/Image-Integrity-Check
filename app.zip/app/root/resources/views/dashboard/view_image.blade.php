@extends('layouts.app')
@section('extra_style')
	<style>
		#upload_zone {
			height: 350px;
			background-image: url(<?php echo asset("img/scrambled/$record->id.png");?>);
			background-repeat: no-repeat;
			background-position: center;
			background-size: contain;
			padding: 60px;
		}

		#btn_encrypt:hover {
			cursor: pointer;
		}

		button:hover {
			cursor: pointer;
		}
	</style>
@endsection
@section('content')
	
	<div class="container" style="margin-top: 30px;">
		<section id="main">
			<div class="row">
                <div class="col-md-4">
					<div style="margin-bottom:20px;">
						<div class="list-group" >
							<a class="list-group-item active main-color-bg">Instructions</a>
							<a class="list-group-item" href="javascript:;" style="height: 300px;overflow-y:scroll;">
								<h3><u>Usage Guidelines</u></h3>
								<p>
									<ol>
										<li>This page an encrypted image and it <code>metadata information</code>.</li>
										<li>To decrypte the image simply click on the <code>Decrypt Image</code> button</li>
									</ol>
								</p>
							</a>
						</div>
					</div>
					
					<div >
						<div class="list-group">
							<a class="list-group-item active main-color-bg" href="#">
								<span class="glyphicon glyphicon-cog" arial-hidden="true"></span><span class="fa fa-bars" arial-hidden="true"></span> Quick Menu
							</a>
							<a class="list-group-item" href="{{URL::route('dashboard')}}"><span class="fa fa-home"></span> Dashboard </a>
							<a class="list-group-item" href="{{URL::route('encryptList')}}"><span class="fa fa-upload"></span> Encrypted List </a>
							<a class="list-group-item" href="{{URL::route('decryptList')}}"><span class="fa fa-download"></span> Decrypted List </a>
							<a class="list-group-item" href="#"><span class="fa fa-lock" arial-hidden="true"></span> Guidelines</a>
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<div class="card">
						<div class="card-header main-color-bg">
                            <span class="fa fa-stats" arial-hidden="true"></span> List of Encrypted Images
                            <a href="{{URL::route('dashboard')}}"><button class="btn btn-xs btn-default pull-right"> Return Back</button></a>
                        </div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="well">
										<h4><span class="fa fa-upload" arial-hidden="true"></span> Encrypted Images</h4><hr/>
                                        <div id="info" style="display:none;" class="alert alert-info">Please note that decrypting an image may take approximately 3 - 5 minutes depending on the dimension of the uploaded image. Thank you for your patience. </div>
										<div id="errorMsg" style="display:none;"></div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div id="upload_zone">
                                                    <center><img src="{{asset('img/loading.gif')}}" id="loader"></center>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-control" style="height: 350px;overflow-y:scroll;">
                                                    <table class="table">
                                                        <tr><th>File Size:</th><td>{{$metadata->size}}</td></tr>
                                                        <tr><th>Mime Type:</th><td>{{$metadata->mime_type}} </td></tr>
                                                        <tr><th>Model:</th><td>{{$metadata->image_model}}</td></tr>
                                                        <tr><th>File Type:</th><td>{{$metadata->file_type}}</td></tr>
                                                        <tr><th>File Date Time:</th><td>{{$metadata->file_date_time}} </td></tr>
                                                        <tr><th>Height:</th><td>{{$metadata->height}}</td></tr>
                                                        <tr><th>Width:</th><td>{{$metadata->width}}</td></tr>
                                                        <tr><th>Orientation: </th><td>{{$metadata->orientation}}</td></tr>
                                                        <tr><th>Light Source: </th><td>{{$metadata->light_source}}</td></tr>
                                                        <tr><th>Component Comfiguration:</th><td>{{$metadata->component_configuration}}</td></tr>
                                                        <tr><th>Focal Length:</th><td> {{$metadata->local_length}} </td></tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div><hr/>
                                        <form action="" method="">
                                            <input type="hidden" value="{{$record->id}}" id="record_id">
                                            <button type="button" class="btn btn-lg btn-success" id="btn_decrypt">Decrypt Image</button>
                                        </form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
@endsection
@section('extra_script')
	<script>
		$(document).ready(function() {
			$("#loader").hide();

			//uploading the image
			$('body').find("#btn_decrypt").on('click', function() {
				var record_id = $("#record_id").val();

                $("#errorMsg").hide();
                $("#btn_decrypt").attr('disabled',true);
                $(this).attr('disabled', true);
                $(this).html("<i class='fa fa-refresh fa-spin'></i> Processing... Please Wait");
                $("#upload_zone").css("opacity","0.6");
                $("#info").fadeIn();
                $("#loader").show();

                $.ajax({
                    url: "{{URL::route('decrypt')}}",
                    method: "POST",
                    data: {
                        '_token': "{{csrf_token()}}",
                        'record_id': record_id,
                        'req': 'decrypt-image'
                    },
                    success: function(rst){
                        if(rst.type == "true") {
                            $("#btn_decrypt").attr('disabled',false);
                            $("#btn_decrypt").html("<i class=''></i> Submit");
                            $("#errorMsg").show();
                            $("#info").hide();
                            $("#errorMsg").html("<div class='alert alert-success'>"+rst.msg+"</div>");
                            $("#loader").hide();
                            location.reload("{{URL::route('decryptList')}}");
                        } else if(rst.type == "false") {
                            $("#btn_decrypt").attr('disabled',false);
                            $("#btn_decrypt").html("<i class=''></i> Try again");
                            $("#errorMsg").show();
                            $("#info").hide();
                            $("#errorMsg").html("<div class='alert alert-danger'>" + rst.msg + "</div>");
                            $("#loader").hide();
                        }
                    },
                    error: function(jqXHR, textStatus, errorMessage){
                        $("#btn_decrypt").attr('disabled',false);
                        $("#btn_decrypt").html("<i class=''></i> Try again");
                        $("#errorMsg").show();
                        $("#info").hide();
                        $("#errorMsg").html("<div class='alert alert-danger'>" + errorMessage + "</div>");
                        $("#loader").hide();
                    }
                });   
			});
		});
	</script>
@endsection