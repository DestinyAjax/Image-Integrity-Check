<?php $__env->startSection('extra_style'); ?>
	<style>
		#upload_zone {
			height: 300px;
			width: 300px;
			border-radius: 10px;
			border: 2px solid grey;
			background-image: url("/img/default.jpg");
			background-repeat: no-repeat;
			background-position: center;
			background-size: contain;
			padding: 60px;
		}

		#btn_encrypt:hover {
			cursor: pointer;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	
	<div class="container" style="margin-top: 30px;">
		<section id="main">
			<div class="row">
				<div class="col-md-4">
					<div style="margin-bottom:20px;">
						<div class="list-group" >
							<a class="list-group-item active main-color-bg">Instructions</a>
							<a class="list-group-item" href="javascript:;" style="height: 300px;overflow-y:scroll;">
								<h3><u>Usage Guidelines</u></h3>
								<p>
									<ol>
										<li>Image dimension must not be greater than <code>700 x 700</code> pixel.</li>
										<li>Choose an image to encrypt then click on the <code>Upload & Encrypt</code> button.</li>
										<li>To view encrypted images click on the <code>Encrypted List</code> link on the quick menu.</li>
									</ol>
								</p>
							</a>
						</div>
					</div>
					
					<div >
						<div class="list-group">
							<a class="list-group-item active main-color-bg" href="#">
								<span class="glyphicon glyphicon-cog" arial-hidden="true"></span><span class="fa fa-bars" arial-hidden="true"></span> Quick Menu
							</a>
							<a class="list-group-item" href="<?php echo e(URL::route('dashboard')); ?>"><span class="fa fa-home"></span> Dashboard </a>
							<a class="list-group-item" href="<?php echo e(URL::route('encryptList')); ?>"><span class="fa fa-upload"></span> Encrypted List </a>
							<a class="list-group-item" href="<?php echo e(URL::route('decryptList')); ?>"><span class="fa fa-download"></span> Decrypted List </a>
							<a class="list-group-item" href="#"><span class="fa fa-lock" arial-hidden="true"></span> Guidelines</a>
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<div class="card">
						<div class="card-header main-color-bg"><span class="fa fa-stats" arial-hidden="true"></span> Image Upload Zone</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="well">
										<h4><span class="fa fa-upload" arial-hidden="true"></span> Upload Image for Encryption</h4><hr/>
										<div id="info" style="display:none;" class="alert alert-info">Please note that encrypting an image may take approximately 3 - 5 minutes depending on the dimension of the uploaded image. Thank you for your patience. </div>
										<div id="errorMsg" style="display:none;"></div>
										<form action="<?php echo e(URL::route('encrypt')); ?>" method="POST" enctype="multipart/form-data">
											<?php echo e(csrf_field()); ?>

											<center>
												<div id="upload_zone">
													<img src="<?php echo e(asset('img/loading.gif')); ?>" id="loader">
												</div><br/>

												<input type="file" id="upload_image" name="upload_image"><br/><br/>
												<button type="button" id="btn_encrypt" class="btn btn-md btn-danger">Upload & Encrypt</button>
											</center>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_script'); ?>
	<script>
		$(document).ready(function() {
			$("#loader").hide();
			$("#btn_encrypt").attr('disabled',true);
			$('body').find("#upload_image").bind("change", function () {
					var fileUpload = $("#upload_image")[0];
					//Check whether the file is valid Image.
					var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.png|.gif)$");
					if (regex.test(fileUpload.value.toLowerCase())) {
							//Check whether HTML5 is supported.
							if (typeof (fileUpload.files) != "undefined") {
									var reader = new FileReader();
									reader.readAsDataURL(fileUpload.files[0]);
									reader.onload = function (e) {
											var image = new Image();
											image.src = e.target.result;
											image.onload = function () {
													var height = this.height;
													var width = this.width;
													if (width <= 700 && height <= 700) {
															$("#errorMsg").hide();
															$("#btn_encrypt").attr('disabled',false);
															$('body').find("#upload_zone").css("background-image", "url("+e.target.result+")");
													} else {
															$("#errorMsg").show();
															$("#errorMsg").html("<div class='alert alert-danger'>Invalid Image Dimension. Try Again!</div>");
															$("#btn_encrypt").attr('disabled',true);
															return false;
													} 
											};
									}
							} else {
								$("#errorMsg").show();
									$("#errorMsg").html("<div class='alert alert-danger'>Invalid file. Try Again!</div>")
									return false;
							}
					} else {
						$("#errorMsg").show();
						$("#errorMsg").html("<div class='alert alert-danger'>Invalid file. Try Again!</div>")
							return false;
					}
			});

			//uploading the image
			$('body').find("#btn_encrypt").on('click', function() {
				var fileUpload = $("#upload_image")[0].files[0];

				if(fileUpload === null) {
					$("#errorMsg").show();
					$("#errorMsg").html("<div class='alert alert-danger'>Please select an image before uploading</div>");
				} else {
					$("#errorMsg").hide();
					$("#upload_image").attr('disabled',true);
					$(this).attr('disabled', true);
					$(this).html("<i class='fa fa-refresh fa-spin'></i> Processing... Please Wait");
					$("#upload_zone").css("opacity","0.3");
					$("#info").fadeIn();
					$("#loader").show();

					var formData = new FormData();
					formData.append('upload_image',fileUpload);
					formData.append('_token',"<?php echo e(csrf_token()); ?>");

					$.ajax({
						url: "<?php echo e(URL::route('encrypt')); ?>",
						method: "POST",
						cache: false,
						processData: false,
						contentType: false,
						data: formData,
						success: function(rst){
							if(rst.type == "true") {
								$("#btn_encrypt").attr('disabled',false);
								$("#btn_encrypt").html("<i class=''></i> Submit");
								$("#errorMsg").show();
								$("#info").hide();
								$("#errorMsg").html("<div class='alert alert-success'>"+rst.msg+"</div>");
								$("#loader").hide();
								$("#upload_image").attr('disabled',false);
								location.reload("<?php echo e(URL::route('encryptList')); ?>");
							} else if(rst.type == "false") {
								$("#btn_encrypt").attr('disabled',false);
								$("#btn_encrypt").html("<i class=''></i> Try again");
								$("#errorMsg").show();
								$("#info").hide();
								$("#errorMsg").html("<div class='alert alert-danger'>" + rst.msg + "</div>");
								$("#loader").hide();
							}
						},
						error: function(jqXHR, textStatus, errorMessage){
							$("#btn_encrypt").attr('disabled',false);
							$("#btn_encrypt").html("<i class=''></i> Try again");
							$("#errorMsg").show();
							$("#info").hide();
							$("#errorMsg").html("<div class='alert alert-danger'>" + errorMessage + "</div>");
							$("#loader").hide();
						}
					});   
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>