<nav class="navbar navbar-expand-md">
  <div class="container">
    <a class="navbar-brand" href="#">Digital Image Integrity Checker</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
        <!-- <li class="nav-item active"><a class="nav-link" href="#">Dashboard <span class="sr-only">(current)</span></a></li> -->
        <!-- <li class="nav-item"><a class="nav-link" href="#">Books</a></li>
        <li class="nav-item"><a class="nav-link disabled" href="#">Users</a></li> -->
      </ul>
      <ul class="navbar-nav navbar-right">
        <li class="nav-item "><a class="nav-link" href="#">Hi, <em><?php echo e(Auth::user()->name); ?></em><span class="sr-only">(current)</span></a></li>
        <li class="nav-item active"><a class="nav-link" href="<?php echo e(URL::route('logout')); ?>"><span class="fa fa-sign-out" arial-hidden="true"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>