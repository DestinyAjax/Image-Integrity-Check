<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateImageInformationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('image_informations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('record_id')->unsigned();
            $table->bigInteger('size');
            $table->string('file_date_time');
            $table->integer('file_type');
            $table->string('mime_type')->nullable();
            $table->string('image_model')->nullable();
            $table->string('width');
            $table->string('height');
            $table->string('orientation')->nullable();
            $table->integer('light_source')->nullable();
            $table->integer('local_length')->nullable();
            $table->integer('flash')->nullable();
            $table->string('component_configuration')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('image_informations');
    }
}
