<?php $__env->startSection('extra_style'); ?>
	<style>
		#before {
			height: 350px;
			background-image: url(<?php echo asset("img/scrambled/$record->id.png")?>);
			background-repeat: no-repeat;
			background-position: center;
			background-size: contain;
			padding: 60px;
		}

        #after {
			height: 350px;
			background-image: url(<?php echo asset("img/unscrambled/$record->id.png")?>);
			background-repeat: no-repeat;
			background-position: center;
			background-size: contain;
			padding: 60px;
		}

		#btn_encrypt:hover {
			cursor: pointer;
		}

		button:hover {
			cursor: pointer;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	
	<div class="container" style="margin-top: 30px;">
		<section id="main">
			<div class="row">
				<div class="col-md-4">
					<div style="margin-bottom:20px;">
						<div class="list-group" >
							<a class="list-group-item active main-color-bg">Instructions</a>
							<a class="list-group-item" href="javascript:;" style="height: 300px;overflow-y:scroll;">
								<h3><u>Usage Guidelines</u></h3>
								<p>
									<ol>
										<li>This page compare the encrypted image and decrypted image.</li>
										<li>Note that image might not return to it fully original state. It all depends on the <code>lossy compression</code> of the image.</li>
									</ol>
								</p>
							</a>
						</div>
					</div>
					
					<div >
						<div class="list-group">
							<a class="list-group-item active main-color-bg" href="#">
								<span class="glyphicon glyphicon-cog" arial-hidden="true"></span><span class="fa fa-bars" arial-hidden="true"></span> Quick Menu
							</a>
							<a class="list-group-item" href="<?php echo e(URL::route('dashboard')); ?>"><span class="fa fa-home"></span> Dashboard </a>
							<a class="list-group-item" href="<?php echo e(URL::route('encryptList')); ?>"><span class="fa fa-upload"></span> Encrypted List </a>
							<a class="list-group-item" href="<?php echo e(URL::route('decryptList')); ?>"><span class="fa fa-download"></span> Decrypted List </a>
							<a class="list-group-item" href="#"><span class="fa fa-lock" arial-hidden="true"></span> Guidelines</a>
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<div class="card">
						<div class="card-header main-color-bg">
                            <span class="fa fa-stats" arial-hidden="true"></span> Decrypted Image Overview
                            <a href="<?php echo e(URL::route('dashboard')); ?>"><button class="btn btn-xs btn-default pull-right"> Return Back</button></a>
                        </div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="well">
										<h4><span class="fa fa-upload" arial-hidden="true"></span> Decrypted Image Overview</h4><hr/>
										<div class="row">
                                            <div class="col-md-6">
                                                <div id="before">
                                                
                                                </div>
                                                <center><h4>Encrypted Image</h4></center>
                                            </div>
                                            <div class="col-md-6">
                                                <div id="after">
                                                
                                                </div>
                                                <center><h5>After Decryption</h5></center>
                                            </div>
                                        </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_script'); ?>
	<script>
		$(document).ready(function() {
			$("#loader").hide();

			//uploading the image
			$('body').find("#btn_decrypt").on('click', function() {
				var record_id = $("#record_id").val();

                $("#errorMsg").hide();
                $("#btn_decrypt").attr('disabled',true);
                $(this).attr('disabled', true);
                $(this).html("<i class='fa fa-refresh fa-spin'></i> Processing... Please Wait");
                $("#upload_zone").css("opacity","0.6");
                $("#info").fadeIn();
                $("#loader").show();

                $.ajax({
                    url: "<?php echo e(URL::route('decrypt')); ?>",
                    method: "POST",
                    // cache: false,
                    // processData: false,
                    // contentType: false,
                    data: {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'record_id': record_id,
                        'req': 'decrypt-image'
                    },
                    success: function(rst){
                        if(rst.type == "true") {
                            $("#btn_decrypt").attr('disabled',false);
                            $("#btn_decrypt").html("<i class=''></i> Submit");
                            $("#errorMsg").show();
                            $("#info").hide();
                            $("#errorMsg").html("<div class='alert alert-success'>"+rst.msg+"</div>");
                            $("#loader").hide();
                            location.reload("<?php echo e(URL::route('decryptList')); ?>");
                        } else if(rst.type == "false") {
                            $("#btn_decrypt").attr('disabled',false);
                            $("#btn_decrypt").html("<i class=''></i> Try again");
                            $("#errorMsg").show();
                            $("#info").hide();
                            $("#errorMsg").html("<div class='alert alert-danger'>" + rst.msg + "</div>");
                            $("#loader").hide();
                        }
                    },
                    error: function(jqXHR, textStatus, errorMessage){
                        $("#btn_decrypt").attr('disabled',false);
                        $("#btn_decrypt").html("<i class=''></i> Try again");
                        $("#errorMsg").show();
                        $("#info").hide();
                        $("#errorMsg").html("<div class='alert alert-danger'>" + errorMessage + "</div>");
                        $("#loader").hide();
                    }
                });   
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>