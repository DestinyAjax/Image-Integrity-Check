<?php $__env->startSection('extra_style'); ?>
	<style>
		#upload_zone {
			height: 300px;
			width: 300px;
			border-radius: 10px;
			border: 2px solid grey;
			background-image: url("/img/default.jpg");
			background-repeat: no-repeat;
			background-position: center;
			background-size: contain;
			padding: 60px;
		}

		#btn_encrypt:hover {
			cursor: pointer;
		}

		button:hover {
			cursor: pointer;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 30px;">
		<section id="main">
			<div class="row">
				<div class="col-md-4">
					<div style="margin-bottom:20px;">
						<div class="list-group" >
							<a class="list-group-item active main-color-bg">Instructions</a>
							<a class="list-group-item" href="javascript:;" style="height: 300px;overflow-y:scroll;">
								<h3><u>Usage Guidelines</u></h3>
								<p>
									<ol>
										<li>This page shows the list of decrypted images.</li>
										<li>To view decrypted image click on the <code>View Image</code> button.</li>
										<li>Images are sorted the way they were encrypted in descending order.</li>
									</ol>
								</p>
							</a>
						</div>
					</div>
					
					<div >
						<div class="list-group">
							<a class="list-group-item active main-color-bg" href="#">
								<span class="glyphicon glyphicon-cog" arial-hidden="true"></span><span class="fa fa-bars" arial-hidden="true"></span> Quick Menu
							</a>
							<a class="list-group-item" href="<?php echo e(URL::route('dashboard')); ?>"><span class="fa fa-home"></span> Dashboard </a>
							<a class="list-group-item" href="<?php echo e(URL::route('encryptList')); ?>"><span class="fa fa-upload"></span> Encrypted List </a>
							<a class="list-group-item" href="<?php echo e(URL::route('decryptList')); ?>"><span class="fa fa-download"></span> Decrypted List </a>
							<a class="list-group-item" href="#"><span class="fa fa-lock" arial-hidden="true"></span> Guidelines</a>
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<div class="card">
						<div class="card-header main-color-bg"><span class="fa fa-stats" arial-hidden="true"></span> List of Decrypted Images</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="well">
										<h4><span class="fa fa-upload" arial-hidden="true"></span> Decrypted Images</h4><hr/>
										<?php if(count($records) < 1): ?>
											<div class="alert alert-danger">No decrypted images found</div>
										<?php else: ?>
										<table class="table table-bordered">
											<thead>
												<tr>
													<th>S/N</th>
													<th>METADATA</th>
													<th>ENCRYPTED DATE</th>
													<th></th>
												</tr>
											</thead>
											<tbody>
                                                <?php ($count=1); ?>
												<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e($count); ?></td>
														<td><img src=<?php echo asset("img/scrambled/$record->id.png");?> height="50" width="50"/> </td>
														<td><?php echo e($record->created_at); ?></td>
														<td><a href="<?php echo e(URL::route('viewDecrypt',$record->id)); ?>"><button class="btn btn-xs btn-info" type="button"> View Image</button></a></td>
													</tr>
                                                <?php ($count++); ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_script'); ?>
	<script>
		$(document).ready(function() {
			$("#loader").hide();
			//uploading the image
			$('body').find("#btn_encrypt").on('click', function() {
				var fileUpload = $("#upload_image")[0].files[0];

				if(fileUpload === null) {
					$("#errorMsg").show();
					$("#errorMsg").html("<div class='alert alert-danger'>Please select an image before uploading</div>");
				} else {
					$("#errorMsg").hide();
					$("#upload_image").attr('disabled',true);
					$(this).attr('disabled', true);
					$(this).html("<i class='fa fa-refresh fa-spin'></i> Processing... Please Wait");
					$("#upload_zone").css("opacity","0.3");
					$("#info").fadeIn();
					$("#loader").show();

					var formData = new FormData();
					formData.append('upload',fileUpload);
					formData.append('_token',"<?php echo e(csrf_token()); ?>");

					$.ajax({
						url: "<?php echo e(URL::route('encrypt')); ?>",
						method: "POST",
						cache: false,
						processData: false,
						contentType: false,
						data: formData,
						success: function(rst){
							if(rst.type == "true") {
								$("#btn_encrypt").attr('disabled',false);
								$("#btn_encrypt").html("<i class=''></i> Submit");
								$("#errorMsg").show();
								$("#info").hide();
								$("#errorMsg").html("<div class='alert alert-success'>"+rst.msg+"</div>");
								$("#loader").hide();
								$("#upload_image").attr('disabled',false);
								location.reload();
							} else if(rst.type == "false") {
								$("#btn_encrypt").attr('disabled',false);
								$("#btn_encrypt").html("<i class=''></i> Try again");
								$("#errorMsg").show();
								$("#info").hide();
								$("#errorMsg").html("<div class='alert alert-danger'>" + rst.msg + "</div>");
								$("#loader").hide();
							}
						},
						error: function(jqXHR, textStatus, errorMessage){
							$("#btn_encrypt").attr('disabled',false);
							$("#btn_encrypt").html("<i class=''></i> Try again");
							$("#errorMsg").show();
							$("#info").hide();
							$("#errorMsg").html("<div class='alert alert-danger'>" + errorMessage + "</div>");
							$("#loader").hide();
						}
					});   
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>